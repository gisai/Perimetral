  XBee Manager Sample Application
  -------------------------------

  The example can be found at https://github.com/digidotcom/XBeeManagerSample
